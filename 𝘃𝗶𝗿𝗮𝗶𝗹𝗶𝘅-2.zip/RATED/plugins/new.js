// new.js

const getContextInfo = (sender) => ({
    mentionedJid: [sender],
    forwardingScore: 999,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363333633057426@newsletter',
        newsletterName: 'RATED TECH',
        serverMessageId: 999
    }
});

module.exports = { getContextInfo };
